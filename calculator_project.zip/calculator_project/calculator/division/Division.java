package calculator.division;

public class Division {
    public static int divide(int a,int b)
    {
    	return a/b;
    }
}
