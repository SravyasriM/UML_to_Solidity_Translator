package calculator.multiplication;

public class Multiplication {
     public static int multiply(int a,int b)
     {
    	 return a*b;
     }
}
