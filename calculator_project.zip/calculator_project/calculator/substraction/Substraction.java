package calculator.substraction;

public class Substraction {
       public static int subtract(int a,int b)
       {
    	   return a-b;
       }
}
